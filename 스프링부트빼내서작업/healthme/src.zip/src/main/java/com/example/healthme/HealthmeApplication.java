package com.example.healthme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthmeApplication.class, args);
	}

}
