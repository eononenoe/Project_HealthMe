package com.example.healthme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthMeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthMeApplication.class, args);
	}

}
