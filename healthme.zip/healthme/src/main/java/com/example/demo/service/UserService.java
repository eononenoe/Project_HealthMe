package com.example.demo.service;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public void join(User user) {
        userRepository.save(user);  // DB insert
    }
    public void delete(String userid) {
        System.out.println("[Service] delete 시작: " + userid);

        if (userRepository.existsById(userid)) {
            System.out.println("[Service] DB에 사용자 존재함: " + userid);
            userRepository.deleteByUserid(userid);
        } else {
            System.out.println("[Service] DB에 없음: " + userid);
        }
    }
}